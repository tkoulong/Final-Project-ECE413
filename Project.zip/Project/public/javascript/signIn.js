function login() {
  let txdata = {
      email: $('#email').val(),
      password: $('#password').val()
  };
  
  $.ajax({
    url: '/users/signin',
    type: 'POST',
    contentType: 'application/json',
    data: JSON.stringify(txdata), 
    dataType: 'json'
  })
    .done(signinSuccess)
    .fail(signinError);
}

function signinSuccess(data, textSatus, jqXHR) {
  // TODO
  window.localStorage.setItem('authToken', data.authToken);
  window.location.replace("/account.html");
}

function signinError(jqXHR, textStatus, errorThrown) {
    $('#ServerResponse').html(JSON.stringify(jqXHR, null, 2)
    );
}

// Handle authentication on page load
$(function() {  
    $('#signin').click(login);
});