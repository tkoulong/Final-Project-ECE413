const db = require("../db");

const userSchema = new db.Schema({
	email:	      { type: String},
	name:	      { type: String},
	password: {type: String},
	lastAccess:   { type: Date, default: Date.now },
	devices:      {type: String, default:"No device"}
});

const User = db.model("User", userSchema);
module.exports = User;
