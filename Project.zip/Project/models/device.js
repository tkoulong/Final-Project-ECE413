const db = require("../db");

const deviceSchema = new db.Schema({
	apiKey:      {type: String},
	deviceID:    {type: String},
    heartRate:   {type: Number},
    SPO2:        {type: Number},
	lastContact: { type: Date, default: Date.now },
});

const Device = db.model("Device", deviceSchema);
module.exports = Device;
